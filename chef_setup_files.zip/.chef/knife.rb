current_dir = File.dirname(__FILE__)
node_name                "deploy"
client_key               "#{current_dir}/deploy.pem"
chef_server_url          "https://chef.vaftl.us/organizations/vistacore"
ssl_verify_mode          :verify_none 
